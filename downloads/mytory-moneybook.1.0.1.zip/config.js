/**
 * If you want to use your own moneybook, create dropbox app on https://www.dropbox.com/developers/apps/
 * And fill below app_key by your own app_key.
 * You must fill dropbox public url to 'OAuth redirect URIs' on app setting.
 */
var MMB_Config = {
    app_key: 'gvpjeh3nzqz0m19',
    version: '1.0.1'
};